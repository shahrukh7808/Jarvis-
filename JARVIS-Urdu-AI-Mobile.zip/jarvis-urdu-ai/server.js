import "dotenv/config";
import express from "express";
import rateLimit from "express-rate-limit";
import OpenAI from "openai";
import path from "node:path";
import { fileURLToPath } from "node:url";

const app = express();
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = process.env.PORT || 3000;
const MODEL = process.env.OPENAI_MODEL || "gpt-6-astra";

app.use(express.json({ limit: "20kb" }));
app.use("/api/", rateLimit({ windowMs: 60_000, limit: 20 }));
app.use(express.static(path.join(__dirname, "public")));

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, configured: Boolean(process.env.OPENAI_API_KEY) });
});

app.post("/api/chat", async (req, res) => {
  try {
    if (!process.env.OPENAI_API_KEY) {
      return res.status(503).json({ error: "سرور پر AI API key ابھی configure نہیں ہوئی۔" });
    }
    const message = typeof req.body?.message === "string" ? req.body.message.trim() : "";
    const history = Array.isArray(req.body?.history) ? req.body.history.slice(-8) : [];
    if (!message) return res.status(400).json({ error: "اپنا سوال لکھیں یا بولیں۔" });
    if (message.length > 4000) return res.status(400).json({ error: "پیغام بہت طویل ہے۔" });

    const safeHistory = history
      .filter(x => x && ["user", "assistant"].includes(x.role) && typeof x.content === "string")
      .map(x => ({ role: x.role, content: x.content.slice(0, 2000) }));

    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const response = await client.responses.create({
      model: MODEL,
      instructions: [
        "You are JARVIS, a helpful, calm, concise mobile voice assistant.",
        "Reply in clear, natural Urdu by default. If the user writes in English or asks for another language, follow that language.",
        "Keep spoken answers reasonably brief and easy to understand.",
        "Do not claim to have opened apps, sent messages, accessed files, or performed actions unless the app actually did so.",
        "For dangerous, illegal, or age-inappropriate requests, give a brief safe response."
      ].join(" "),
      input: [...safeHistory, { role: "user", content: message }]
    });

    res.json({ reply: response.output_text || "معذرت، اس وقت جواب تیار نہیں ہو سکا۔" });
  } catch (err) {
    console.error("AI request failed:", err?.message || err);
    res.status(500).json({ error: "جواب حاصل نہیں ہو سکا۔ سرور کی سیٹنگ چیک کریں۔" });
  }
});

app.get("*", (_req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));
app.listen(PORT, () => console.log(`JARVIS running on port ${PORT}`));
