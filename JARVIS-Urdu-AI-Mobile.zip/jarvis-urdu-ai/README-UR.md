# JARVIS اردو AI — موبائل ویب ایپ

## اس پراجیکٹ میں کیا ہے؟
- اردو چیٹ انٹرفیس
- براؤزر کی Speech Recognition سے بول کر سوال
- Speech Synthesis سے جواب سننا (اگر فون میں اردو آواز دستیاب ہو)
- OpenAI Responses API کے ذریعے AI جواب
- PWA فائلیں، تاکہ compatible browser میں Home Screen پر انسٹال کیا جا سکے

## اہم سیکیورٹی بات
API key کو کبھی `public/` فولڈر، HTML، JavaScript، GitHub repository یا کسی کو بھیجنے والے پیغام میں نہ رکھیں۔ اسے صرف server کے `.env` میں رکھیں۔ `.env` کو GitHub پر اپ لوڈ نہ کریں۔ API استعمال کے اخراجات ہو سکتے ہیں؛ اکاؤنٹ اور بلنگ کی ذمہ داری کسی سرپرست/بالغ منتظم کے ساتھ طے کریں۔

## چلانے کا طریقہ
1. کمپیوٹر/سرور پر Node.js 20 یا اس سے نیا ورژن نصب ہو۔
2. اس فولڈر میں terminal کھولیں۔
3. `npm install` چلائیں۔
4. `.env.example` کی نقل بنا کر `.env` نام رکھیں۔
5. `.env` میں سرور کی خفیہ `OPENAI_API_KEY` رکھیں۔ ضرورت ہو تو `OPENAI_MODEL` کو اپنے اکاؤنٹ میں دستیاب ماڈل کے مطابق بدلیں۔
6. `npm start` چلائیں۔
7. `http://localhost:3000` کھولیں۔

## انٹرنیٹ پر ہوسٹنگ
اسے ایسے Node.js hosting provider پر deploy کریں جو environment variables سپورٹ کرتا ہو۔ `OPENAI_API_KEY` کو hosting dashboard کے Environment Variables میں شامل کریں؛ اسے source code میں نہ لکھیں۔ Deploy کے بعد HTTPS URL استعمال کریں، کیونکہ مائیکروفون کے لیے secure context ضروری ہے۔

## موبائل پر انسٹال
HTTPS ویب سائٹ کو Android Chrome میں کھولیں، پھر browser menu سے "Install app" یا "Add to Home screen" منتخب کریں۔ PWA install کا آپشن browser/device کے حساب سے مختلف ہو سکتا ہے۔

## حدود
- وائس شناخت ہر browser میں یکساں نہیں؛ کچھ Android browsers میں بہتر چلتی ہے۔
- اردو TTS آواز فون میں موجود voice pack پر منحصر ہے۔
- یہ ورژن بات چیت کرتا ہے؛ خود سے WhatsApp message بھیجنا، فون کی ہر ایپ کنٹرول کرنا یا ہمیشہ background میں "Hey Jarvis" سننا اس میں شامل نہیں۔
- API جواب کے لیے انٹرنیٹ اور فعال API key ضروری ہیں۔
